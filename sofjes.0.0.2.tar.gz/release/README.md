# Software Jester Engine

Simple 2.5D Raycasting engine.

Can render solid walls, floors and ceilings + one direction sprites.

## Control

 * W - move forward
 * S - move backward
 * A - strafe left
 * D - strafe right
 * Q - rotate left
 * E - rotate right

## To start

Execute "run.bat" on Windows, or "run.sh" on Linux-based OS.

## Requirements

Linux: SDL 2.0.8


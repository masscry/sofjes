# Software Jester Engine

Simple Raycast engine.

## Control

 * W - move forward
 * S - move backward
 * a - strafe left
 * d - strafe right
 * q - rotate left
 * e - rotate right

## To start

Execute "run.bat" on Windows, or "run.sh" on Linux-based OS.

## Requirements

Linux: SDL 2.0.8


#!/usr/bin/env bash
./bin/sofjes
